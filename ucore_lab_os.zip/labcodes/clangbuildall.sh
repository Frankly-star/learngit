cd lab1; make clean; USELLVM=1 make; cd ..
cd lab2; make clean; USELLVM=1 make; cd ..
cd lab3; make clean; USELLVM=1 make; cd ..
cd lab4; make clean; USELLVM=1 make; cd ..
cd lab5; make clean; USELLVM=1 make; cd ..
cd lab6; make clean; USELLVM=1 make; cd ..
cd lab7; make clean; USELLVM=1 make; cd ..
cd lab8; make clean; USELLVM=1 make; cd ..
