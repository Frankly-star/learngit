<?php

namespace frontend\controllers;

class AthleticsController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
