<?php

namespace frontend\controllers;

class CyclingtrackController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
