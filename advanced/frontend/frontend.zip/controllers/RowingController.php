<?php

namespace frontend\controllers;

class RowingController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
