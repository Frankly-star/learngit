<?php

namespace frontend\controllers;

class TempController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
