<?php

namespace frontend\controllers;

class ArtisticswimmingController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
