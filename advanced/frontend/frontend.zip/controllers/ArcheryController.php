<?php

namespace frontend\controllers;

class ArcheryController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
