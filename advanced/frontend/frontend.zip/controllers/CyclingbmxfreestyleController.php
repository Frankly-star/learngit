<?php

namespace frontend\controllers;

class CyclingbmxfreestyleController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
