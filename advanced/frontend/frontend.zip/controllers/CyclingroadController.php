<?php

namespace frontend\controllers;

class CyclingroadController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
