<?php

/* @var $this yii\web\View */
?>
<div class="site-about">

    <p>This is the About page. You may modify the following file to customize its content:</p>

</div>
